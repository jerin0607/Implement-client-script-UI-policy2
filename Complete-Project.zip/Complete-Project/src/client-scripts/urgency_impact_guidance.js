/**
 * Client Script: Incident - Urgency/Impact Guidance
 * Table: incident | Type: onChange | Field: urgency
 */
function onChange(control, oldValue, newValue, isLoading) {
    if (isLoading || newValue === '') return;
    g_form.hideFieldMsg('urgency', true);
    // 1 = High, 3 = Low
    if (newValue === '1' && g_form.getValue('impact') === '3') {
        g_form.showFieldMsg('urgency',
            'High urgency with Low impact is unusual. Please verify.', 'info');
    }
}
