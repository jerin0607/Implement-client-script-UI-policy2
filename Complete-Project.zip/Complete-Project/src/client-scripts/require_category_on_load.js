/**
 * Client Script: Incident - Require Category on Load
 * Table: incident | Type: onLoad
 */
function onLoad() {
    if (g_form.isNewRecord() && !g_form.getValue('category')) {
        g_form.showFieldMsg('category', 'Select a category to ensure correct routing.', 'info');
    }
}
