/**
 * UI Policy Script: Incident - Resolution Fields
 * "Reverse if false" enabled; run scripts checked.
 */
function onCondition() {
    g_form.setMandatory('close_code', true);
    g_form.setMandatory('close_notes', true);
}
