# Implement Client Script & UI Policy (Incident)

ServiceNow project that enforces consistent, accurate data entry on the **Incident** table
using Client Scripts and UI Policies.

> Built from the document title/problem statement only (full doc text was not readable).
> Adjust field names, conditions and messages to match your requirements.

## Structure
```
src/client-scripts/   Client Script source (paste into System Definition > Client Scripts)
src/ui-policies/      UI Policy definitions + scripts (System Definition > UI Policies)
config/               Table / field configuration reference
docs/                 Test cases
package.json          Project metadata + lint tooling
```

## Components
| Type | Name | Trigger | Purpose |
|------|------|---------|---------|
| Client Script | Incident - Validate Short Description | onSubmit | Require >= 10 chars |
| Client Script | Incident - Urgency/Impact Guidance | onChange (urgency) | Warn on High urgency with Low impact |
| Client Script | Incident - Require Category on Load | onLoad | Focus/highlight category when empty |
| UI Policy | Incident - Resolution Fields | state = Resolved/Closed | Close code + close notes mandatory and visible |
| UI Policy | Incident - On Hold Reason | state = On Hold | Hold reason mandatory |
| UI Policy | Incident - Assignment Group | state = In Progress | Assignment group mandatory |

## Install
1. Open the instance, go to **System Definition > Client Scripts** / **UI Policies**.
2. Create each record using the matching file in `src/`, with Table = `incident`.
3. Test using `docs/TEST_CASES.md`.

## Dev
```
npm install
npm run lint
```
