# Test Cases
1. Submit incident with short description "Help" -> blocked with error message.
2. Submit with 10+ char short description -> saves.
3. Set Urgency High, Impact Low -> info message appears on Urgency.
4. Set State Resolved -> Close code and Close notes become mandatory.
5. Set State On Hold -> Hold reason mandatory.
6. Set State In Progress -> Assignment group mandatory.
7. Open new incident with empty category -> info message on Category.
